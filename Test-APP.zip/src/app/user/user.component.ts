import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  users = ["Rajendran", "Palanisamy", "Periyasamy"];

  constructor() { }

  ngOnInit() {
  }

  addUser(userName: HTMLInputElement) {
    this.users.splice(0, 0, userName.value);
  }

  deleteUser(index) {
    this.users.splice(index, 1);
  }


}
