import { Component, OnInit } from '@angular/core';
import { PostService } from '../services/post.service';

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements  OnInit {
  
  posts: any[];
  constructor(private postService: PostService) {
  }
  

  ngOnInit() {
    this.postService.getAll().subscribe(data => {
    console.log(JSON.stringify(data));
    //this.posts = data.
    this.posts = JSON.parse(JSON.stringify(data));
    console.log(this.posts);
    }, error=> {
      alert("error while fetching posts");
    });

  }

  postTitle(title: HTMLInputElement) {
    console.log(title.value);
    
    this.postService.create(title.value).subscribe(response => {
      console.log(JSON.stringify(response));
      this.posts.splice(0, 0, JSON.parse(JSON.stringify(response)));
      let newTitle = this.posts[0].title;
      setTimeout(a =>{
        console.log("timed Out");
        title.value = "Tests "+newTitle;
      }, 10000);
      title.value = "1234567890";
    }, error=> {
      alert("error while fetching posts");
    });

   }

}
