import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../authentication.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent  {

  constructor(private authenticationService: AuthenticationService, private router: Router ) { }
  invalidLogin: boolean;

  login(loginDetails) {

    console.log(loginDetails.uname);
    console.log(loginDetails.password);

    let token = this.authenticationService.validate(loginDetails.uname, loginDetails.password);
    if(token) {
      localStorage.setItem("token", token);
      this.invalidLogin = false;
      this.router.navigate(['']);
    } else {
      this.invalidLogin = true;
    }

  }

}
