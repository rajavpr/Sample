import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-post-detail',
  templateUrl: './post-detail.component.html',
  styleUrls: ['./post-detail.component.css']
})
export class PostDetailComponent implements OnInit {

  postId: string;

  constructor(private route: ActivatedRoute) { }
  
  ngOnInit() {

    this.route.paramMap.subscribe(params => {
      console.log(params);
      console.log(params.get('postId'));
      this.postId = params.get('postId');
    }
      );

  }

}
