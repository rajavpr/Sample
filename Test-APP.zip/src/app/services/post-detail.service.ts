import { Injectable } from '@angular/core';
import { DataService } from './data.service';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PostDetailService extends DataService {

  constructor(httpclient: HttpClient) { 
    super(httpclient, "http://jsonplaceholder.typicode.com/posts");
  }

  

}
