import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private httpclient: HttpClient, private url: string) { }


  getAll() {
    return this.httpclient.get(this.url);
  }

  create(resource: any) {
    return  this.httpclient.post(this.url, resource);
  }
  

}
