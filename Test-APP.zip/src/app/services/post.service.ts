import { Injectable, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DataService } from './data.service';

@Injectable({
  providedIn: 'root'
})
export class PostService extends DataService {

  constructor(httpclient: HttpClient) { 
    super(httpclient, "http://jsonplaceholder.typicode.com/posts");
  }

}
