import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {



  constructor(private router: Router) { }

  validate(uname: string, password: string) {

    if(uname === "Raja" && password === "1234")   {
      return "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IlJhamVuZHJhbiBQZXJpeWFzYW15IiwiaWF0IjoxNTE2MjM5MDIyfQ.wWksdkRuPL_EycIvQYXgb6YFKpuUEtXx_A3WghXkfiA";
    } else {
      return null;
    }

  }

  isAuthenticated() {
    let token = localStorage.getItem("token");
    if(token) {
      return true;
    } else {
      return false;
    }
  }

  logout() {
    localStorage.removeItem("token");
    this.router.navigate(['/']);
  }

}
