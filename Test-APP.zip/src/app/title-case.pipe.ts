import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'titleCase'
})
export class TitleCasePipe implements PipeTransform {

  transform(value: String): String {
    
    if(!value) {
      return null;
    }
    console.log("===========>" +value)
    //alert(value);
    let words = value.split(' ');
    for(let i=0; i<=words.length; i++) {
      if(words[i])
      words[i] = words[i].substring(0,1).toUpperCase() +''+ words[i].substring(1,words[i].length).toLowerCase();
      console.log(words[i])
    }
    let returnValue = words.join(' ');

    console.log("===========> return value" +returnValue)
    return returnValue;
  }

}
