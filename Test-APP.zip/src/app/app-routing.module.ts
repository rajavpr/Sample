import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from "./app.component";
import { PostComponent } from "./post/post.component";
import { UserComponent } from "./user/user.component";
import { HomeComponent } from "./home/home.component";
import { PostDetailComponent } from "./post-detail/post-detail.component";
import { PostCommentComponent } from "./post-comment/post-comment.component";
import { LoginComponent } from './login/login.component';
import { AuthGuard } from './auth-guard.service';

const routes: Routes = [
  { path: '', component: HomeComponent, canActivate: [AuthGuard] },
  { path: 'posts', component: PostComponent , canActivate: [AuthGuard]},
  { path: 'posts/:postId', component: PostDetailComponent, canActivate: [AuthGuard] },
  { path: 'posts/:postId/comment', component: PostCommentComponent, canActivate: [AuthGuard] },
  { path: 'users', component: UserComponent, canActivate: [AuthGuard] },
  { path: 'login', component: LoginComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }


